# Chacon, a Markdown Viewer for the Progit book

## Usage

    $ cd couchapp
    $ make en
    $ couchapp push . progit
		$ open http://127.0.0.1:5984/progit/_design/chacon/_show/chapter/01-chapter1

## Requirements

GNU Make

Couchapp >= 0.6.0

    $ easy_install -U couchapp

